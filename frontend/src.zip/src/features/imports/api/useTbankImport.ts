import { useMutation, useQueryClient } from "@tanstack/react-query";
import { importTbank } from "../../../shared/api/endpoints/tbank";
import { queryKeys } from "../../../shared/api/queryKeys";

export function useTbankImport() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: importTbank,
    // после загрузки список выписок на странице профиля обновится сам
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: queryKeys.imports }),
  });
}
