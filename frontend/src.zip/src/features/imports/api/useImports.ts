import { useQuery } from "@tanstack/react-query";
import { imports } from "../../../shared/api/endpoints/imports";
import { queryKeys } from "../../../shared/api/queryKeys";

export function useImports() {
  return useQuery({ queryKey: queryKeys.imports, queryFn: imports });
}
