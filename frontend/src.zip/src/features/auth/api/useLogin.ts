import { useMutation, useQueryClient } from "@tanstack/react-query";
import { login } from "../../../shared/api/endpoints/login";
import { queryKeys } from "../../../shared/api/queryKeys";

export function useLogin() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: login,
    onSuccess: (user) => queryClient.setQueryData(queryKeys.me, user),
  });
}
