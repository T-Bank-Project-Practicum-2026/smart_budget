import { useQuery } from "@tanstack/react-query";
import { me } from "../../../shared/api/endpoints/me";
import { queryKeys } from "../../../shared/api/queryKeys";

export function useMe() {
  return useQuery({ queryKey: queryKeys.me, queryFn: me });
}
