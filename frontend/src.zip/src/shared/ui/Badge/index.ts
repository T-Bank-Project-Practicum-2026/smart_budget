export { default } from "./Badge";
