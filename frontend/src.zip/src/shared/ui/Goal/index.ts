export { default } from "./Goal";
