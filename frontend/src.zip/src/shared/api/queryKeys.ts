// Все ключи кэша в одном месте, чтобы они не разъезжались
// (раньше login писал в ["auth","me"], а страница читала ["me"]).
export const queryKeys = {
  me: ["me"] as const,
  imports: ["imports"] as const,
};
