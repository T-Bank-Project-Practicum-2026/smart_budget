import { QueryClient } from "@tanstack/react-query";
import { ApiError } from "./client";

// Говорим TanStack Query, что ошибки у нас всегда ApiError.
// Благодаря этому `error` в useQuery/useMutation типизирован сам,
// и не нужно писать useMutation<Data, ApiError, Vars>.
declare module "@tanstack/react-query" {
  interface Register {
    defaultError: ApiError;
  }
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      retry: (failureCount, error) => {
        // 4xx (401, 404, 422...) повторять бессмысленно
        if (error instanceof ApiError && error.status >= 400 && error.status < 500) {
          return false;
        }
        return failureCount < 2;
      },
    },
  },
});
